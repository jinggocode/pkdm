@layout('_layout/mahasiswa/index')

@section('title')Beranda@endsection

@section('content')

<div class="callout callout-warning">
  <h4>Selamat Datang <b>{{$user->first_name}}</b></h4>

  <p style="font-size: 15px">Kamu belum mengisi semua kuisioner, Silahkan lakukan pengisian dibawah ini</p>
</div>

<div class="box box-default">
  <div class="box-header with-border">
    <h3 class="box-title">Pilih Mata Kuliah lalu lakukan pengisian kuisioner</h3>
  </div>
  <div class="box-body">
    <table class="table table-striped" style="margin-top: 20px">
      <thead>
        <th>Nama Mata Kuliah / Nama Dosen</th>
        <th>Aksi</th>
      </thead>
      <tbody>
      <?php if(empty($makul)): ?>
          <tr>
              <td colspan="6" align="center">Tidak ada Data</td>
          </tr>
      <?php else: ?>
          <?php $no = 1 ?>
          @foreach($makul as $row)
            <tr>
              <td>{{($row->makul->jenis == '0')?'TEORI':'PRAKTEK'}} {{$row->makul->nama}} - {{$row->dosen->nama}}</td>
              <td>
                <a href="{{site_url('mahasiswa/kuesioner/isi/'.$row->id)}}" class="btn btn-info"><i class="fa fa-send"></i> Isi</a>
              </td>
            </tr>
          @endforeach
      <?php endif ?>
      </tbody>
    </table>
  </div>
  <!-- /.box-body -->
</div>
<!-- /.box -->
@endsection
