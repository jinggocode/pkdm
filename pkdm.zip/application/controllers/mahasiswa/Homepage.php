<?php

/**
*
*/
class Homepage extends MY_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->_accessable = TRUE;
		$this->load->helper(array('dump'));
		$this->load->model('admin/user_model');
		$this->load->model('admin/pengampu_model');
		$this->load->model('admin/makul_model');
		$this->load->model('admin/dosen_model');
		$this->load->model('admin/kelas_model');
		$this->load->model('admin/mahasiswa_model');
	}

	public function index()
	{
		$data['user'] = (object)$this->ion_auth->user()->row();
		$mahasiswa = $this->mahasiswa_model->where('id_user', $data['user']->id)->get();

		$data['makul'] = $this->pengampu_model
				->where('id_kelas', $mahasiswa->id_kelas)
				->with_dosen()
				->with_makul()
				->get_all();
		// dump($mahasiswa->id_kelas);

		$this->render('mahasiswa/home', $data);
	}

	public function tambah()
	{
		dump('ini tambah');
	}

}
