<?php

/**
*
*/
class Kuesioner extends MY_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->_accessable = TRUE;
		$this->load->helper(array('dump'));
		$this->load->model('admin/user_model');
		$this->load->model('admin/pengampu_model');
		$this->load->model('admin/makul_model');
		$this->load->model('admin/kelas_model');
		$this->load->model('admin/dosen_model');
		$this->load->model('admin/kuesioner_model');
		$this->load->model('admin/kategori_kuesioner_model');
	}

	public function isi($id)
	{
		$data['user'] = (object)$this->ion_auth->user()->row();

		$data['data'] = $this->pengampu_model
				->with_dosen()
				->with_makul()
				->get($id);

		$data['kategori'] = $this->kuesioner_model
				->where('jenis', '1')
				->fields('id_kategori')
				->with_kategori()
				->group_by('id_kategori')
				->order_by('id_kategori', 'DESC')
				->get_all();

		// dump($data['kategori']);

		$this->generateCsrf();
		$this->render('mahasiswa/kuesioner/isi', $data);
	}

	public function save()
	{
		$data = $this->input->post();
		echo "<pre>";
		var_dump($data);
		echo "</pre>";

		while ($fruit_name = current($data)) {
				$id_kuesioner = key($data);
		    echo $id_kuesioner.'='.$data[$id_kuesioner].'<br />';

		    next($data);
		}
	}

}
